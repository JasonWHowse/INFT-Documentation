# INFT

Contract souce code for INFT.
INFT implements the OpenZeppelin token library.
