## `ERC2771Context`



Context variant with ERC2771 support.


### `constructor(address trustedForwarder)` (internal)





### `isTrustedForwarder(address forwarder) → bool` (public)





### `_msgSender() → address sender` (internal)





### `_msgData() → bytes` (internal)








