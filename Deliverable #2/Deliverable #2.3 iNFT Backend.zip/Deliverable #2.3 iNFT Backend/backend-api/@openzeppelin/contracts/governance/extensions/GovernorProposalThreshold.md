## `GovernorProposalThreshold`



Extension of {Governor} for proposal restriction to token holders with a minimum balance.

_Available since v4.3._
_Deprecated since v4.4._


### `propose(address[] targets, uint256[] values, bytes[] calldatas, string description) → uint256` (public)








