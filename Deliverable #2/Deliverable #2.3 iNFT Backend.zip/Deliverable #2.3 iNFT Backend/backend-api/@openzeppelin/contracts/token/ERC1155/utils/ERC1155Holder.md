## `ERC1155Holder`



_Available since v3.1._


### `onERC1155Received(address, address, uint256, uint256, bytes) → bytes4` (public)





### `onERC1155BatchReceived(address, address, uint256[], uint256[], bytes) → bytes4` (public)








