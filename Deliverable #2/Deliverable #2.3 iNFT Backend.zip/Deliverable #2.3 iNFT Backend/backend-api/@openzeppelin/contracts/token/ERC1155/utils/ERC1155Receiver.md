## `ERC1155Receiver`



_Available since v3.1._


### `supportsInterface(bytes4 interfaceId) → bool` (public)



See {IERC165-supportsInterface}.




